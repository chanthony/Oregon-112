#diseases.txt

def generateDiseases(data):
    diseaseList = []#keep the diseases as a list
    diseaseList.append(Disease("performed a ritual sacrifice to the 112 gods",
                                "grade",5))#generate each disease and store it
    diseaseList.append(Disease("forgot to backup their work and lost it",
                                "grade",-10))
    diseaseList.append(Disease("angered the great Kosbie","grade",-20))
    diseaseList.append(Disease("""forgot a parentheses in their code and spent
                                15 hours looking for it""","grade",-5))
    diseaseList.append(Disease("caught dysentery","energy",-50))
    diseaseList.append(Disease("got dumped","energy",-30))
    diseaseList.append(Disease("hung out with their friends","energy",20))
    data.diseaseList = diseaseList#store the list

class Disease(object):#the various effects
    def __init__(self,name,effect,amount):
        self.name = name#not the name but what the disease is
        self.effect = effect#what the disease effects
        self.amount = amount#the size of the impact
        if self.amount < 0:#if negative
            self.change = "lost"#whether we lost or gained amount
        else:#positive
            self.change = "gained"

    def takeEffect(self,char,player):
        if self.effect == "energy":#if the energy is hurt
            if player.energy>0:#don't drop below 0 energy
                player.energy += self.amount#change the energy
        elif self.effect == "grade":
            char.grade += self.amount
        else:
            #we clearly havent' coded this yet so let me know
            raise NameError("This disease effect has not been coded yet!")

    def showDisease(self,char):#shows the disease dialogue
        if self.effect == "energy":
            line = "You %s.\n" % self.name
            #ex. You forgot your homework
            line += "You %s %d energy." % (self.change , abs(self.amount))
        else:#if it's something other than energy
            line = "%s %s. \n" % (char.name , self.name)
            #ex. Jimmy forgot to close his parentheses
            line += "%s %s %d %s points" % (char.name,self.change,
                                            abs(self.amount),self.effect)
            #ex. Jimmy gained 15 energy
        return line