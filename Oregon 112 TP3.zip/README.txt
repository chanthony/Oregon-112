Oregon 112 is an adaptation of the classic Dysentery simulator, Oregon Trail.

In order to run the game, all you need to do is run the file named Oregon 112.py